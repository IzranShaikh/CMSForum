<?php include"includes/header.php";?>

<body>

    <!-- Navigation -->
    <?php 
        
        include "includes/navigation.php";
        
    ?>
    
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                
                <h1 class="page-header">
                    Blog
                    <small></small>
                </h1>
                
               <?php
                    //Displaying Published Posts
                
                    $query = "SELECT * FROM posts WHERE post_status = 'published' ";
                    $published_posts_query_res = mysqli_query( $connection , $query );
                    $total_published_posts = mysqli_num_rows($published_posts_query_res);
                    if($total_published_posts == 0)
                    {
                        echo "<pre>No Posts!!!</pre>";
                    }
                
                    $query = "SELECT * FROM posts";
                
                    $select_all_posts = mysqli_query( $connection , $query);
                    
                    while($data_fetched = mysqli_fetch_assoc($select_all_posts))
                    {
                        $post_id = $data_fetched['post_id'];
                        $post_title = $data_fetched['post_title'];
                        $post_author = $data_fetched['post_author'];
                        $post_date = $data_fetched['post_date'];
                        $post_image = $data_fetched['post_image'];
                        $post_content = $data_fetched['post_content'];
                        $post_status = $data_fetched['post_status'];
                    if($post_status == 'published')
                    {
                    
               ?>
               

                <!-- First Blog Post -->
                <h2>
                    <a href="post.php?p_id=<?php echo $post_id; ?>"> <?php echo $post_title; ?> </a>
                </h2>
                <p class="lead">
                Posted by <a href="author_posts.php?author=<?php echo $post_author; ?>"> <?php echo $post_author; ?> </a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $post_date; ?> </p>
                <hr>
                <a href="post.php?p_id=<?php echo $post_id; ?>">
                <img class="img-responsive" src="images/<?php echo $post_image; ?>" alt="Image Missing" />
                </a>
                <hr>
                <p> <?php echo $post_content; ?> </p>
                <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>
                <hr>
                
                <?php 
                    }#else ends
                    }#while ends
                ?>

                <!-- Pager -->

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php
                
                include "includes/sidebar.php";
                
            ?>

        </div>
        <!-- /.row -->

        <hr>


<?php 
    
    include "includes/footer.php";
    
?>