<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test</title>
</head>
<body>
    <?php

/*      Similar Search Testing
        $search = 'Metasploit';
        $srclen = strlen( $search );
        Customizing Search Engine
        $search_substr = substr( $search , $srclen/2 );
        $search_rtrim = rtrim( $search , $search_substr );
        echo "Exact Search: " . $search . "<br>" . "Search Subbed: " . $search_substr . "<br>" . "Search Rtrimmed: " . $search_rtrim;*/

    ?>
    
    
    <!--Dynamic Desired Google Chart-->
    
    <?php
    
        $connection = mysqli_connect('localhost','root','','cms');
        if(!$connection)
        {
            die("404 DATABASE NOT FOUND");
        }
        
        function comfirmquery($result)
        {
            global $connection;
            if(!$result)
            {
                die("Query Failed " . mysqli_error($connection));
            }
        }
    
        #Total Posts
        $query = "SELECT * FROM posts";
        $get_posts_query = mysqli_query( $connection , $query );
        comfirmquery($get_posts_query);
        $total_posts = mysqli_num_rows($get_posts_query);
    
        #Published Posts
        $query = "SELECT * FROM posts WHERE post_status = 'published' ";
        $get_published_posts_query = mysqli_query( $connection , $query );
        comfirmquery($get_published_posts_query);
        $pub_posts = mysqli_num_rows($get_published_posts_query);
    
        #Draft Posts
        $query = "SELECT * FROM posts WHERE post_status = 'draft' ";
        $get_draft_posts_query = mysqli_query( $connection , $query );
        comfirmquery($get_draft_posts_query);
        $draft_posts = mysqli_num_rows($get_draft_posts_query);
    
        #Total Comments
        $query = "SELECT * FROM comments";
        $get_comments_query = mysqli_query( $connection , $query );
        comfirmquery($get_comments_query);
        $total_comments = mysqli_num_rows($get_comments_query);
    
        #Approved Comments
        $query = "SELECT * FROM comments WHERE comment_status = 'approved' ";
        $get_app_comm_query = mysqli_query( $connection , $query );
        comfirmquery($get_app_comm_query);
        $app_comms = mysqli_num_rows($get_app_comm_query);
    
        #Unapproved Comments
        $query = "SELECT * FROM comments WHERE comment_status = 'unapproved' ";
        $get_unapp_comm_query = mysqli_query( $connection , $query );
        comfirmquery($get_unapp_comm_query);
        $unapp_comms = mysqli_num_rows($get_unapp_comm_query);
    
        #Total Users
        $query = "SELECT * FROM users";
        $get_users_query = mysqli_query( $connection , $query );
        comfirmquery($get_users_query);
        $total_users = mysqli_num_rows($get_users_query);
    
        #Admin Users
        $query = "SELECT * FROM users WHERE user_role = 'admin' ";
        $get_admin_users_query = mysqli_query( $connection , $query );
        comfirmquery($get_admin_users_query);
        $admin_users = mysqli_num_rows($get_admin_users_query);
    
        #Common Users
        $query = "SELECT * FROM users WHERE user_role = 'user' ";
        $get_comm_users_query = mysqli_query( $connection , $query );
        comfirmquery($get_comm_users_query);
        $comm_users = mysqli_num_rows($get_comm_users_query);
        
        #Array Collection
        $Data_Name = [ 'Posts' , 'Comments' ,'Total Users' ];
        $Data_Value = [ $total_posts , $total_comments ,  $total_users ];  
        $Authorized_Val = [$pub_posts , $app_comms , $admin_users];
        $Unauthorized_Val = [$draft_posts , $unapp_comms , $comm_users];
        
    ?>
    <hr/>
    <script src="loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() 
        {
            var data = google.visualization.arrayToDataTable([
            ['Activity', 'Total' , 'Authorized' , 'Unauthorized'],
                /*['2014', 1000, 400, 200],
          ['2015', 1170, 460, 250],
        ['2125',321,321,321]*/
                
                <?php
                    for( $i=0; $i<3; $i++ )
                    {
                        echo " [ '{$Data_Name[$i]}' " . "," . " {$Data_Value[$i]}" . "," . "{$Authorized_Val[$i]}" . "," . "{$Unauthorized_Val[$i]} ] , " ;
                        
                    }
                ?>  
            ]);

            var options = {
            chart: {
            title: 'Overall Activity',
            subtitle: 'Posts , Comments , Users , Categories',
            }
            };

            var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

            chart.draw(data, google.charts.Bar.convertOptions(options));
        }
    </script>
    
    <!--<div id="columnchart_material" style="width: 800px; height: 500px;"></div>-->
    <!--Chart-->
    
<?php 

/*
$post_content='<p>$comment_content$comment_content$comment_content$comment_content$comment_content$comment_content$comment_content$comment_cont ############################$comment_content$commencomment_content$comment_content$comment_content$comment_content$comment_content$comment_cont ############################$comment_content$commencomment_content$comment_content$comment_content$comment_content$comment_content$comment_cont ############################$comment_content$commencomment_content$comment_content$comment_content$comment_content$comment_content$comment_cont ############################$comment_content$comment_content$comment_content$comment_con</p>';
$len = strlen($post_content);
echo "Before Trimming: " . $len . $post_content;

$trimmedlen = ($len/2);
    
$post_content = substr( $post_content , $trimmedlen );
$completetrimmed = strlen($post_content);
echo "<br/>" . "After Trimming: " . floor($completetrimmed) . "<br/>" . $post_content;
*/

?>
    
</body>
</html>