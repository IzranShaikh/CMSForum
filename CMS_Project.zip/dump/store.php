<?php

    #Tor Browser
    $Tor_Desc = "Tor is free software for enabling anonymous communication. The name is derived from an acronym for the original software project name The Onion Router. Tor directs Internet traffic through a free, worldwide, volunteer overlay network consisting of more than seven thousand relays to conceal a user's location and usage from anyone conducting network surveillance or traffic analysis."
    
    
    
?>