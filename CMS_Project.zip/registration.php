<!--Header and DB Connection-->
<?php  include "includes/header.php"; ?>
<!-- Navigation -->
<?php  include "includes/navigation.php"; ?>
 
<?php

    if( isset($_POST['register']))
    {   
        $username_r = $_POST['username_r'];
        $username_r = mysqli_real_escape_string( $connection , $username_r );
        $email_r = $_POST['email_r'];
        $email_r = mysqli_real_escape_string( $connection , $email_r );
        $password_r = $_POST['password_r'];
        $password_r = mysqli_real_escape_string( $connection , $password_r );
        
        if( !empty($username_r) and !empty($email_r) and !empty($password_r) )
        {
        
            #getting hash from db
            $query = "SELECT randsalt from users";
            $select_randsalt_query = mysqli_query( $connection , $query );
            if(!$select_randsalt_query)
            {
                die("Query Failed " . mysqli_error($connection));
            }
            while( $data_fetched = mysqli_fetch_assoc( $select_randsalt_query ) )
            {
                $HASH = $data_fetched['randsalt'];
            }
            #Password Encryption using Hash
            $password_r = crypt( $password_r , $HASH );
            
            #User Registration
            $query = "INSERT INTO users(username,user_password,user_email,user_role) VALUES('{$username_r}' , '{$password_r}' , '{$email_r}' , 'user' ) ";
            $registration_query = mysqli_query( $connection , $query );
            if(!$registration_query)
            {
                die("Query Failed " . mysqli_error($registration_query));
            }
            $message = "<span style='color:green;'>You've been Successfully Signed Up</span>";

        }
        else
        {
            $message = "<span style='color:red;'>These Fields Cannot Be Empty</span>";
        }
    }
    else
    {
        $message = "";
    }

?>
 
<!-- Page Content -->
<div class="container">
    <section id="login">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-xs-offset-3">
                    <div class="form-wrap">
                    <h1>Sign Up</h1>
                        <form action="registration.php" method="post" id="login-form" autocomplete="off">
                            <?php echo $message; ?>
                            <div class="form-group">
                                <label for="username" class="sr-only">Username</label>
                                <input type="text" name="username_r" id="username" class="form-control" placeholder="Enter Username">
                            </div>
                             <div class="form-group">
                                <label for="email" class="sr-only">Email</label>
                                <input type="email" name="email_r" id="email" class="form-control" placeholder="somebody@gmail.com">
                            </div>
                             <div class="form-group">
                                <label for="password" class="sr-only">Password</label>
                                <input type="password" name="password_r" id="password" class="form-control" placeholder="Password">
                            </div>
                            <input type="submit" name="register" id="btn-login" class="btn btn-primary btn-lg btn-block" value="Sign Up">
                        </form>

                    </div>
                </div> <!-- /.col-xs-12 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </section>
<hr>
<?php include "includes/footer.php";?>