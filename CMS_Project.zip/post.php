<?php include"includes/header.php";

?>
<body>

    <!-- Navigation -->
    <?php 
        
        include "includes/navigation.php";
        
    ?>
    
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                
                <h1 class="page-header">
                    <a href="index.php" class="backbutton"><small>back</small></a>
                    <style>
                        a.backbutton:hover
                        {
                            text-decoration: none;
                        }
                    </style>
                    Post
                </h1>
                
               <?php
                    
                    if(isset($_GET['p_id']))
                    {
                        $show_post_id = $_GET['p_id'];
                        
                        //Specific Posts
                        $query = "SELECT * FROM posts WHERE post_id = $show_post_id ";
                        $select_all_posts = mysqli_query( $connection , $query);
                        while($data_fetched = mysqli_fetch_assoc($select_all_posts))
                        {

                            $post_title = $data_fetched['post_title'];
                            $post_author = $data_fetched['post_author'];
                            $post_date = $data_fetched['post_date'];
                            $post_image = $data_fetched['post_image'];
                            $post_content = $data_fetched['post_content'];
                        }
                    
               ?>
               

                <!-- First Blog Post -->
                <h2>
                    <a href="#"> <?php echo $post_title; ?> </a>
                </h2>
                <p class="lead">
                Posted by <a href="#"> <?php echo $post_author; ?> </a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> <?php echo $post_date; ?> </p>
                <hr>
                <img class="img-responsive" src="images/<?php echo $post_image; ?>" alt="Image Missing" />
                <hr>
                <p> <?php echo $post_content; ?> </p>
                <!--<a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>-->
                
                
                <?php } else 
                    {
                        echo "<pre>No post to display</pre>";
                    }
                ?>

                <!-- Pager -->

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php
                
                include "includes/sidebar.php";
                
            ?>

        </div>
        <!-- /.row -->


                <hr>

                <!-- Blog Comments -->

                <!-- Comments Form -->
                <div class="well">
                    <h4>Leave a Comment:</h4>
                    <?php
                        
                        if( isset($_POST['submit_comment']))
                        {
                            #comment by user
                            $comm_author = $_SESSION['username_s'];
                            $comm_email = $_SESSION['emailid_s'];
                            $comm_content = $_POST['comment_content'];
                            $comm_content = mysqli_real_escape_string( $connection , $comm_content );
                            $comm_post_id = $show_post_id;
                            
                            if( !empty($comm_content) )
                            {
                                $query = "INSERT INTO comments( comment_post_id , comment_author, comment_email, comment_content, comment_status, comment_date ) ";
                                $query .= " VALUES( {$comm_post_id} , '{$comm_author}' , '{$comm_email}' , '{$comm_content}' , 'unapproved' , now() ) ";

                                $publish_comm_query = mysqli_query( $connection , $query );

                                confirmquery($publish_comm_query);

                                $query = "UPDATE posts SET post_comment_count = post_comment_count + 1 WHERE post_id = $show_post_id";
                                $comment_count_query = mysqli_query( $connection , $query );
                                confirmquery($comment_count_query);

                                echo "<span style=' color:red; '>Your comment has been sended and waiting for approval</span>";
                            }
                            else
                            {
                                echo "<script> alert('This Field Cannot Be Empty') </script>";
                            }
                        }
                    
                    ?>

                    <?php
                    if( isset($_SESSION['username_s']) )
                    {
                    ?>

                    <form method="post">
                       
                        <div class="form-group">
                            <label for="comment">Your Comment</label>
                                <script src="admins/includes/tinymce/tinymcenested/tinymce.min.js"></script>
                                <!--Modern WYSIWYG-->
                                <?php include"admins/includes/modernwysiwyg.php"; ?>
                                
                            <textarea class="form-control" rows="3" name="comment_content"></textarea>
                        </div>
                        
                        <input type="submit" class="btn btn-primary" value="Comment" name="submit_comment"/>
                        
                    </form>

                    <?php

                    }
                    else
                    {
                        echo "<span style='color:red;'>Please Signin or Register</span>";
                    }

                    ?>
                </div>

                <hr>

                
                <!-- Displaying Comments -->
                
                <div class="comment" class="col-lg-8">
                <label for="Comments" class="form-control">Comments</label>
                <?php
                    $get_id_comm = $_GET['p_id'];
                    $query = "SELECT * FROM comments WHERE comment_status = 'approved' AND comment_post_id = {$get_id_comm} ORDER BY comment_id DESC";
                    $select_comment_query = mysqli_query( $connection , $query );
                    confirmquery($select_comment_query);
        
                    while($data_fetched = mysqli_fetch_assoc($select_comment_query))
                    {
                        $comment_to_display = $data_fetched['comment_content'];
                        $comment_posted_by = $data_fetched['comment_author'];
                        $comment_posted_date = $data_fetched['comment_date'];
                ?>
                    
                    <div class="media">
                    <!-- Posted Comments -->
                       
                        <a class="pull-left" href="#">
                            <!-- user profile - under construction  --><!--<img class="media-object" src="http://placehold.it/64x64" alt="">-->
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="#"><?php echo $comment_posted_by; ?> </a>
                                <small><?php echo $comment_posted_date; ?></small>
                            </h4>
                                <?php echo $comment_to_display; ?>
                            <hr/>
                        </div>
                    </div>
                    
                    <?php } ?>
                </div>
                <!--Comment styled in dump reply_comment.php-->
                

                <!-- Comment with Reply in dump reply_comment.php-->
                
<?php 
        
    include "includes/footer.php";
    
?>