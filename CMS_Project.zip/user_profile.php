<?php include"includes/header.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Page</title>
    <style>
    
        body
        {
            margin: 0;
            padding: 0;
        }
        
    </style>
</head>
<body class="container">
 <div class="row">
    <div class="col-lg-12">
        <a href="index.php">back</a>
        <h1 class="page-header">Profile</h1>
        <!--Displaying Profile-->
        <div class="col-lg-4">
            <!--User Profile Photo-->

            <img src="./images/<?php echo $_SESSION['user_image_s']; ?>" width="300" alt="img missing"/>

        </div>

        <div class="col-lg-8">
            <!--User Details-->
            <strong><big>Username: </big></strong><?php echo $_SESSION['username_s']; ?><br /><br /><br />
            <strong><big>First name: </big></strong><?php echo $_SESSION['firstname_s']; ?><br /><br /><br />
            <strong><big>Last name: </big></strong><?php echo $_SESSION['lastname_s']; ?><br /><br /><br />
            <strong><big>Email ID: </big></strong><?php echo $_SESSION['emailid_s']; ?><br /><br /><br />
            <strong><big>Role: </big></strong><?php echo $_SESSION['user_role_s']; ?>

        </div>

    </div>
</div>