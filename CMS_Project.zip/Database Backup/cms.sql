-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2018 at 04:58 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(12, 'PHP'),
(13, 'JavaScript'),
(15, 'BootStrap 4'),
(16, 'Hacking');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `comment_post_id` int(11) NOT NULL,
  `comment_author` varchar(50) NOT NULL,
  `comment_email` varchar(200) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(100) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(19, 5, 'Izran Shaikh', 'izran.s12121221321323@gmail.com', 'Best Tool for Network Security and Penetration Testing and lot more :)', 'approved', '2018-03-09'),
(20, 5, 'Sam Shaikh', 'sameer007@underworld.com', 'I HACKED THE WORLD using METASPLOIT ;)', 'approved', '2018-03-09'),
(22, 2, 'Izran Shaikh', 'izran.s032@gmail.com', '<p>YaYYYYY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</p>', 'unapproved', '2018-03-11'),
(23, 3, 'MOBA', 'shaikhmubasshir4@gmail.com', '<blockquote>\r\n<p style=\"text-align: center;\"><strong><em>I Hate Bootsrap because meko nahi aata bootstrap</em></strong></p>\r\n<p style=\"text-align: center; padding-left: 330px;\"><strong><em>- MB*</em></strong></p>\r\n</blockquote>', 'approved', '2018-03-11'),
(24, 4, 'MOBA', 'shaikhmubasshir4@gmail.com', '<blockquote><em><strong>Use Tor Browser Be Anonymous</strong></em><em><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</strong></em></blockquote>\r\n<blockquote style=\"padding-left: 210px;\"><em><strong>-MB*</strong></em></blockquote>', 'approved', '2018-03-11'),
(25, 5, 'Sam', 'sam007@hackerspace.com', '<p><strong>Believe ME</strong></p>', 'approved', '2018-03-11'),
(27, 5, 'MOBA', 'shaikhmubasshir4@gmail.com', '<p style=\"text-align: left;\"><em><strong>wow how you made this it is like&nbsp;<span style=\"color: #00ccff;\">wordpad<img src=\"admins/includes/tinymce/plugins/emoticons/img/smiley-surprised.gif\" alt=\"surprised\" /></span></strong></em></p>', 'approved', '2018-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `post_category_id` int(11) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` int(11) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_comment_count`, `post_status`) VALUES
(1, 0, 'PHP Course', 'Izran Shaikh', '2018-04-05', 'php.jpg', '<p>An Awesome PHP Course by Edwin Diaz at Udemy.com Check it out - https://www.udemy.com/php-for-complete-beginners-includes-msql-object-oriented/</p>', 'PHP , php , Edwin Diaz , edwin diaz , course , udemy , Udemy', 2, 'published'),
(2, 0, 'Brackets', 'Izran Shaikh', '2018-04-06', 'brackets.jpg', '<p>I found this Editor best for Web Development there are many more which are even better but this does satisfy all needs for Web Development as being a text Editor. The only thing which i dont like about this text editor is that it Live Previews HTML or PHP codes only with Google Chrome not our desired Web Browser. Still this is an amazing text editor as it has many Extensions/Plugins that make coding even better. DOWNLOAD LINK -&gt; http://brackets.io Download it and start CODING THE WEB ;)</p>', 'TextEditor , CODETHEWEB , BRACKETS , brackets , code the web , text editor', 1, 'published'),
(3, 0, 'BootStrap', 'Izran Shaikh', '2018-03-11', 'bootstrap.jpg', '  Bootstrap is a free and open-source front-end library for designing websites and web applications. It contains HTML- and CSS-based design templates for typography, forms, buttons, navigation and other interface components, as well as optional JavaScript extensions. Unlike many web frameworks, it concerns itself with front-end development only.  ', 'bootstrap , styling , css library , web design , framework , getbootstrap , pre defined library', 1, 'published'),
(4, 0, 'Tor', 'Izran Shaikh', '2018-03-11', 'tor.jpg', '    Tor is free software for enabling anonymous communication. The name is derived from an acronym for the original software project name The Onion Router. Tor directs Internet traffic through a free, worldwide, volunteer overlay network consisting of more than seven thousand relays to conceal a user\'s location and usage from anyone conducting network surveillance or traffic analysis.\r\n\r\nDownload Tor and Be anoymous - \r\nhttps://www.torproject.org/    ', 'tor browser , Tor Browser , Anonymous tor project', 2, 'published'),
(5, 0, 'MetaSploit', 'Izran Shaikh', '2018-03-11', 'metasploit.jpg', '   The Metasploit Project is a computer security project that provides information about security vulnerabilities and aids in penetration testing and IDS signature development.   ', 'metasploit , vulnerability , testing , penetration , metesploit', 5, 'published'),
(6, 0, 'DeAuth', 'anonymous', '2018-09-24', 'deauth.JPG', '<p><em><strong>DeAuth Attack</strong></em></p>', 'DeAuth Attack , Hacking', 0, 'published'),
(7, 0, 'DNS Spoofing Attack', 'anonymous', '2018-09-24', 'dnsspoofed.JPG', '<p>DNS Spoofing</p>', 'dns , spoofing , attack', 0, 'published');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randsalt` varchar(255) NOT NULL DEFAULT '$y$10$usesomecrazysaltstring'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randsalt`) VALUES
(16, 'demo', '$1$VExlnTKE$fLKyE8l7iG04x/cMp9qY0/', '', '', 'cewvvwvewv@gmail.com', '', 'admin', '$y$10$usesomecrazysaltstring'),
(18, 'IzranShaikh', '$yoOITl0Hs1ZI', '', '', 'izran.s032@gmail.com', '', 'admin', '$y$10$usesomecrazysaltstring');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
