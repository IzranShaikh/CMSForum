<?php include"includes/admin_header.php"; ?>
<?php include"functions.php"; 

if( $_SESSION['user_role_s'] == 'admin' )
{#if start

?>

<body>
<h1>Users Page</h1>
    <div id="wrapper">

        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Users Section
                        </h1>
                        
                        <!--Table HEre-->
                        
                        <?php
                            if(isset($_GET['source']))
                            {
                                $source = $_GET['source'];
                                
                            }
                            else
                            {
                                $source='';
                            }
                        
                            switch($source)
                            {
                                case 'add_user':
                                    include "includes/add_users.php";
                                    break;
                                    
                                default:
                                    include "includes/view_all_users.php";
                                    break;
                            }
                        ?>
                        
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->


<?php 
}
else
{
    header("Location: ../index.php");
}
 include"includes/admin_footer.php"; ?>