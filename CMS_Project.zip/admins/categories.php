<?php include"includes/admin_header.php"; ?>
<?php include"functions.php"; 

if( $_SESSION['user_role_s'] == 'admin' )
{#if start

?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Category Section
                        </h1>
                        
                        <div class="col-xs-6">
                           
                           <?php
                                #Adding Category Functionality
                                add_cat();
                            
                            ?>
                           
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="Cat Title">Add Category</label>
                                    <input type="text" name="cat_title_add" class="form-control" />
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="addcatbutton" value="Add Category"/>
                                </div>
                            </form>
                            
                            
                            <!--Update Category-->
                            <?php
                                if( isset($_GET['editcat']) )
                                {
                                    edit_cat();
                                }
                            ?>
                            
                        </div>
                        
                        <div class="col-xs-6">
                            <table class="table table-responsive table-hover">
                                <tr>
                                    <th>ID</th>
                                    <th>Category Name</th>
                                    <th colspan="2">Action</th>
                                </tr>
                                    
                                    <?php
                                        #Viewing and Deleting Categories
                                        show_all_cats();
                                        del_cat();
                                    ?>
                                    
                            </table>
                            
                        </div>
                        
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->


<?php }
else
{
    header("Location: ../index.php");
}
include"includes/admin_footer.php"; ?>