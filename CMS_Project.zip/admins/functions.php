<?php

function confirmquery($result)
{
    global $connection;
    
    if(!$result)
    {
        die("Query Failed " . mysqli_error($connection));
    }
}

function del_cat()
{
    global $connection;
    if( isset($_GET['deletecat']) )
    {
        $del_cat_id = $_GET['deletecat'];
        $query = "DELETE FROM categories WHERE cat_id = {$del_cat_id} ";
        $delete_cat = mysqli_query( $connection , $query );
        confirmquery($delete_cat);
        header("Location: categories.php");
    }
}

function add_cat()
{
    global $connection;
    if( isset($_POST['addcatbutton']) and !empty($_POST['cat_title_add']) )
    {
        $cat_title = $_POST['cat_title_add'];
        $query = "INSERT INTO categories(cat_title) VALUES ('$cat_title')";
        $cat_added = mysqli_query( $connection , $query );
        confirmquery($cat_added);
    }
}

function edit_cat()
{
    global $connection;
    ?>
    
    <form action="" method="post">
    <div class="form-group">
        <label for="Cat Title">Edit Category</label>
        <input type="text" name="cat_title_edit" class="form-control" />
    </div>
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="editcatbutton" value="Edit Category"/>
    </div>

    <?php

        #Updating Category
        if( isset($_GET['editcat']) and !empty($_POST['cat_title_edit']) )
        {
            $cat_id_edit = $_GET['editcat'];
            $cat_title_edit = $_POST['cat_title_edit'];
            
            #updating category
            $query = "UPDATE categories SET cat_title='{$cat_title_edit}' WHERE cat_id = {$cat_id_edit} ";
            $edit_cat_query = mysqli_query( $connection , $query );
            confirmquery($edit_cat_query);
            header("Location: categories.php");
        }

    ?>

    </form>
    
    <?php
}

function show_all_cats()
{
    global $connection;
    $query = "SELECT * FROM categories";
    $select_all_cats = mysqli_query( $connection , $query );
    while($data_fetched = mysqli_fetch_assoc($select_all_cats))
    {
        $cat_id = $data_fetched['cat_id'];
        $cat_title = $data_fetched['cat_title'];
        echo '<tr>';
        echo "<td>{$cat_id}</td>";
        echo "<td>{$cat_title}</td>";
        echo "<td><a class='btn btn-primary' href='categories.php?editcat={$cat_id}'>Edit</a></td>";
        echo "<td><a class='btn btn-danger' href='categories.php?deletecat={$cat_id}'>Delete</a></td>";
    }
}

?>