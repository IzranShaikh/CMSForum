<?php

    #Draft Posts
    $query = "SELECT * FROM posts WHERE post_status  = 'draft' ";
    $res_for_draft_post_cnt_query = mysqli_query( $connection , $query );
    $total_draft_posts = mysqli_num_rows($res_for_draft_post_cnt_query);

    #Approved Comments
    $query = "SELECT * FROM comments WHERE comment_status  = 'approved' ";
    $res_for_app_comm_cnt_query = mysqli_query( $connection , $query );
    $total_app_comments = mysqli_num_rows($res_for_app_comm_cnt_query);

    #Admins
    $query = "SELECT * FROM users WHERE user_role  = 'admin' ";
    $res_for_admin_cnt_query = mysqli_query( $connection , $query );
    $total_admins = mysqli_num_rows($res_for_admin_cnt_query);   

    #Published Posts
    $query = "SELECT * FROM posts WHERE post_status = 'published' ";
    $get_published_posts_query = mysqli_query( $connection , $query );
    $pub_posts = mysqli_num_rows($get_published_posts_query);

    #Unapproved Comments
    $query = "SELECT * FROM comments WHERE comment_status = 'unapproved' ";
    $get_unapp_comm_query = mysqli_query( $connection , $query );
    $unapp_comms = mysqli_num_rows($get_unapp_comm_query);

    #Common Users
    $query = "SELECT * FROM users WHERE user_role = 'user' ";
    $get_comm_users_query = mysqli_query( $connection , $query );
    $comm_users = mysqli_num_rows($get_comm_users_query);

    #Array Collection
    $Data_Name = [ 'Posts' , 'Comments' ,'Users' ];
    $Data_Value = [ $total_posts , $total_comments ,  $total_users ];  
    $Authorized_Val = [$pub_posts , $total_app_comments , $total_admins];
    $Unauthorized_Val = [$total_draft_posts , $unapp_comms , $comm_users];

?>
   

<script type="text/javascript" src="./js/loader.js"></script>
<script type="text/javascript">
  google.charts.load('current', {'packages':['bar']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var data = google.visualization.arrayToDataTable([
      ['Activity' , 'Total' , 'Authorized' , 'Unauthorized'],

      <?php

            for( $i=0; $i<3; $i++ )
            {
                echo " [ '{$Data_Name[$i]}' " . "," . " {$Data_Value[$i]}" . "," . "{$Authorized_Val[$i]}" . "," . "{$Unauthorized_Val[$i]} ] , " ;
            }

      ?>
            
    ]);

    var options = {
      chart: {
        title: 'Overall Activity',
        subtitle: 'Posts , Comments , Users , Categories',
      }
    };

    var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

    chart.draw(data, google.charts.Bar.convertOptions(options));
  }
</script>
<div id="columnchart_material" style="width: 'auto'; height: 500px;"></div>