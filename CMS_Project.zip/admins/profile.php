<?php include"includes/admin_header.php"; ?>
<?php include"functions.php"; 

if( $_SESSION['user_role_s'] == 'admin' )
{#if start

?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Profile</h1>
                        <!--Displaying Profile-->
                        <div class="col-lg-3">
                            <!--User Profile Photo-->
                            
                            <img src="./images/all_users/<?php echo $_SESSION['user_image_s']; ?>" width="200" alt="img missing"/>
                            
                        </div>
                        
                        <div class="col-lg-9">
                            <!--User Details-->
                            <strong><big>Username: </big></strong><?php echo $_SESSION['username_s']; ?><br /><br /><br />
                            <strong><big>First name: </big></strong><?php echo $_SESSION['firstname_s']; ?><br /><br /><br />
                            <strong><big>Last name: </big></strong><?php echo $_SESSION['lastname_s']; ?><br /><br /><br />
                            <strong><big>Email ID: </big></strong><?php echo $_SESSION['emailid_s']; ?><br /><br /><br />
                            <strong><big>Role: </big></strong><?php echo $_SESSION['user_role_s']; ?>
                            
                        </div>
                        
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->


<?php
 
}#if ends
else
{
    header("Location: ../index.php");
}

include"includes/admin_footer.php"; ?>