<table class="table table-responsive table-hover">
    <thead>
        <tr>
            <th>Id</th>
            <!--<th>Category</th>-->
            <th>Username</th>
            <th>Password</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Email</th>
            <th>Image</th>
            <th>Role</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
           
            <?php

                $query = "SELECT * FROM users";
                $users_fetched_res = mysqli_query( $connection , $query );
                while($data_fetched_posts = mysqli_fetch_assoc($users_fetched_res))
                {
                    $user_id = $data_fetched_posts['user_id'];
                    $username = $data_fetched_posts['username'];
                    $user_password = $data_fetched_posts['user_password'];
                    $user_firstname = $data_fetched_posts['user_firstname'];
                    $user_lastname = $data_fetched_posts['user_lastname'];
                    $user_email = $data_fetched_posts['user_email'];
                    $user_image = $data_fetched_posts['user_image'];
                    $user_role = $data_fetched_posts['user_role'];

                    echo '<tr>';
                    echo "<td>{$user_id}</td>";
                    echo "<td>{$username}</td>";
                    echo "<td>{$user_password}</td>";
                    echo "<td>{$user_firstname}</td>";
                    echo "<td>{$user_lastname}</td>";
                    echo "<td>{$user_email}</td>";
                    echo "<td><img alt='img missing' width=50 src='./images/all_users/{$user_image}' /></td>";
                    echo "<td>{$user_role}</td>";
                    #ILLEGAL - echo "<td><a class='btn btn-info' href='posts.php?source=edit_post&p_id={$post_id}'>Edit</a></td>";
                    echo "<td><a class='btn btn-danger' href='users.php?delete_user={$user_id}' >Ban User</a></td>";
                    echo "</tr>";
                }

            ?>
            
    </tbody>
</table>


<?php

    #Deleting Posts
    if( isset($_GET['delete_user']) )
    {
        $del_user_id = $_GET['delete_user'];
        $query = "DELETE FROM users WHERE user_id = {$del_user_id}";
        $del_user_query = mysqli_query( $connection , $query );
        confirmquery($del_user_query);
        header("Location: users.php");
    }
    
?>