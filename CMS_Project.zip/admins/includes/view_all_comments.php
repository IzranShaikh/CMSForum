<table class="table table-responsive table-hover table-bordered">
    <thead>
        <tr>
            <th>Id</th>
            <!--<th>Category</th>-->
            <th>Post ID</th>
            <th>Comm Author</th>
            <th>Comm Email</th>
            <th>Comm Content</th>
            <th>Actual Post</th>
            <th>Comm Status</th>
            <th>Comm Date</th>
            <th colspan="3"><center>Action</center></th>
        </tr>
    </thead>
    <tbody>
            <?php

                $query = "SELECT * FROM comments";
                $comments_fetched_res = mysqli_query( $connection , $query );
                while($data_fetched_comments = mysqli_fetch_assoc($comments_fetched_res))
                {
                    //viewing comment in table
                    $comment_id = $data_fetched_comments['comment_id'];
                    $comment_post_id = $data_fetched_comments['comment_post_id'];
                    $comment_author = $data_fetched_comments['comment_author'];
                    $comment_email = $data_fetched_comments['comment_email'];
                    $comment_content = $data_fetched_comments['comment_content'];
                    $comment_content = mysqli_real_escape_string( $connection , $comment_content );
                    $comment_status = $data_fetched_comments['comment_status'];
                    $comment_date = $data_fetched_comments['comment_date'];
                    $comment_content = substr( $comment_content , 1 , 25 );
                    echo '<tr>';
                    
                    echo "<td>{$comment_id}</td>";
                    echo "<td>{$comment_post_id}</td>";
                    echo "<td>{$comment_author}</td>";
                    echo "<td>{$comment_email}</td>";
                    echo "<td>{$comment_content}</td>";
                    
                    $query = "SELECT * FROM posts WHERE post_id = $comment_post_id";
                    $post_by_comm_query = mysqli_query( $connection , $query );
                    confirmquery($post_by_comm_query);
                    while($data_fetched = mysqli_fetch_assoc($post_by_comm_query))
                    {
                        $post_id_for_comm = $data_fetched['post_id'];
                        $post_title_for_comm = $data_fetched['post_title'];
                        echo "<td><a href='../post.php?p_id=$post_id_for_comm'>$post_title_for_comm</a></td>";
                    }
                    
                    echo "<td>{$comment_status}</td>";
                    echo "<td>{$comment_date}</td>";
                    echo "<td><a class='btn btn-success' href='comments.php?approve_comm=$comment_id'>Approve</a></td>";
                    echo "<td><a class='btn btn-info' href='comments.php?unapprove_comm=$comment_id'>Unapprove</a></td>";
                    echo "<td><a class='btn btn-danger' href='comments.php?delete_comm=$comment_id'>Delete</a></td>";
                    echo "</tr>";
                }

            ?>
            
    </tbody>
</table>


<?php
    
    #Comment Functionality of Admin - approvedd , Unapprovedd , Delete
    
    #Approving Posts
    if( isset($_GET['approve_comm']) )
    {
        $approve_comm_id = $_GET['approve_comm'];
        $query = "UPDATE comments SET comment_status = 'approved' WHERE comment_id = {$approve_comm_id} ";
        $approve_comm_query = mysqli_query( $connection , $query );
        confirmquery($approve_comm_query);
        header("Location: comments.php");
    }

    #Unapproving Posts
    if( isset($_GET['unapprove_comm']) )
    {
        $unapprove_comm_id = $_GET['unapprove_comm'];
        $query = "UPDATE comments SET comment_status = 'unapproved' WHERE comment_id = {$unapprove_comm_id} ";
        $unapprove_comm_query = mysqli_query( $connection , $query );
        confirmquery($unapprove_comm_query);
        header("Location: comments.php");
    }

    #Deleting Posts
    if( isset($_GET['delete_comm']) )
    {
        $del_comm_id = $_GET['delete_comm'];
        $query = "DELETE FROM comments WHERE comment_id = {$del_comm_id}";
        $del_comm_query = mysqli_query( $connection , $query );
        confirmquery($del_comm_query);
        header("Location: comments.php");
    }
    
?>