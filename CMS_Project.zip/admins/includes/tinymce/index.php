<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>shot hua be</title>
	<script type="text/javascript" src="tinymce.min.js"></script>
	<script>
		tinymce.init({ selector:'textarea' });
	</script>
</head>
<body>
	<textarea>asia kya</textarea>
</body>
</html>