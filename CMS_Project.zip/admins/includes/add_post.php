<?php
    
    if( isset($_POST['add_post_submit']) )
    {
        #$add_post_id = $_POST['add_post_id'];
        $add_post_cat_id = $_POST['add_post_cat_id'];
        $add_post_title = $_POST['add_post_title'];
        $add_post_author = $_POST['add_post_author'];
        #$add_post_date = date('d-m-y');
        
        #Handling Image
        $add_post_img = $_FILES['add_post_img']['name'];
        $add_post_img_temp = $_FILES['add_post_img']['tmp_name'];
        move_uploaded_file( $add_post_img_temp , "../images/$add_post_img" );
        
        $add_post_content = $_POST['add_post_content'];
        $add_post_tags = $_POST['add_post_tags'];
        #$add_post_comm_cnt = $_POST['add_post_comm_cnt'];
        $add_post_comm_cnt = 0;
        $add_post_status = $_POST['add_post_status'];
        
        $query = "INSERT INTO posts(post_category_id,post_title,post_author,post_date,post_image,post_content,post_tags,post_comment_count,post_status) ";
        $query .= "VALUES( {$add_post_cat_id} , '{$add_post_title}' , '{$add_post_author}' , now() , '{$add_post_img}' , '{$add_post_content}' , '{$add_post_tags}' , {$add_post_comm_cnt} , '{$add_post_status}' )";
        
        $add_post_query = mysqli_query( $connection , $query );
        
        confirmquery($add_post_query);
        
        echo "<pre>Post Added</pre>";
        
    }
    
?>

<form action="" method="post" enctype="multipart/form-data">
    
    <!--<div class="form-group">
        <label for="Post id">Post Id</label>
        <input type="text" name="add_post_id" class="form-control"/>
    </div>-->
    
    <div class="form-group">
        <label for="Post Cat Id">Post Cat Id</label>
        <input type="text" name="add_post_cat_id" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Title">Post Title</label>
        <input type="text" name="add_post_title" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Author">Post Author</label>
        <input type="text" name="add_post_author" class="form-control"/>
    </div>
    
    <!--<div class="form-group">
        <label for="Post Date">Post Date</label>
        <input type="text" name="add_post_date" class="form-control"/>
    </div>-->
    
    <div class="form-group">
        <label for="Post Image">Post Image</label>
        <input type="file" name="add_post_img"/>
    </div>
    
    <div class="form-group">
        <label for="Post Content">Post Content</label>
        <!--Modern WYSIWYG-->
        <?php include"modernwysiwyg.php"; ?>
        <textarea name="add_post_content" class="form-control" rows="3"></textarea>
    </div>
    
    <div class="form-group">
        <label for="Post Tags">Post Tags</label>
        <input type="text" name="add_post_tags" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Comm Count">Post Comm Count</label>
        <input type="text" name="add_post_comm_cnt" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Status">Post Status</label>
        <input type="text" name="add_post_status" class="form-control"/>
    </div>
    
    <input type="submit" class="btn btn-success" value="Add Post" name="add_post_submit" />
    
</form> 