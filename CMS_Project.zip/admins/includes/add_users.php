<?php
    
    if( isset($_POST['add_user_submit']) )
    {
        $add_username = $_POST['add_user_username'];
        $add_user_password = $_POST['add_user_password'];
        
        $add_user_firstname = $_POST['add_user_firstname'];
        $add_user_lastname = $_POST['add_user_lastname'];
        $add_user_email = $_POST['add_user_email'];
        
        #Handling User Image
        $add_user_img = $_FILES['add_user_img']['name'];
        $add_user_img_temp = $_FILES['add_user_img']['tmp_name'];
        move_uploaded_file( $add_user_img_temp , "../images/$add_user_img" );
        
        $add_user_role = $_POST['add_user_role'];
        
        #getting hash from db
        $query = "SELECT randsalt from users";
        $select_randsalt_query = mysqli_query( $connection , $query );
        if(!$select_randsalt_query)
        {
            die("Query Failed " . mysqli_error($connection));
        }
        $data_fetched = mysqli_fetch_assoc( $select_randsalt_query );
        $HASH = $data_fetched['randsalt'];
        
        $add_user_password = crypt( $add_user_password , $HASH );
        
        $query = "INSERT INTO users(username,user_password,user_firstname,user_lastname,user_email,user_image,user_role) ";
        $query .= "VALUES( '{$add_username}' , '{$add_user_password}' , '{$add_user_firstname}' , '{$add_user_lastname}' , '{$add_user_email}' , '{$add_user_img}' , '{$add_user_role}' )";
        
        $add_post_query = mysqli_query( $connection , $query );
        
        confirmquery($add_post_query);
        
        echo "<pre>User Added</pre>";
        
    }
    
?>

<form action="" method="post" enctype="multipart/form-data">
    
    <div class="form-group">
        <label for="Post Title">Username</label>
        <input type="text" name="add_user_username" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Author">Password</label>
        <input type="password" name="add_user_password" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Image">First Name</label>
        <input type="text" name="add_user_firstname" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Content">Last Name</label>
        <input type="text" name="add_user_lastname" class="form-control" />
    </div>
    
    <div class="form-group">
        <label for="Post Tags">Email</label>
        <input type="text" name="add_user_email" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Comm Count">Image</label>
        <input type="file" name="add_user_img"/>
    </div>
    
    <div class="form-group">
        <label for="Post Status">Role</label>
        <input type="text" name="add_user_role" placeholder="admin,user" class="form-control"/>
    </div>
    
    <input type="submit" class="btn btn-success" value="Add User" name="add_user_submit" />
    
</form>