<?php

    #CheckBoxFunctionality

    if( (isset($_POST['submit'])) and (isset($_POST['checkBoxArray'])) )
    {
        foreach($_POST['checkBoxArray'] as $cBAV)
        {
            $bulk_options = $_POST['bulk_options'];
            
            switch($bulk_options)
            {
                case 'publish':
                    $query = "UPDATE posts SET post_status = 'published' WHERE post_id = $cBAV";
                    $publishing_post_via_checkboxes_query = mysqli_query( $connection , $query );
                    confirmquery($publishing_post_via_checkboxes_query);
                    header("Location: posts.php");
                    break;
                    
                case 'draft':
                    $query = "UPDATE posts SET post_status = 'draft' WHERE post_id = $cBAV";
                    $drafting_post_via_checkboxes_query = mysqli_query( $connection , $query );
                    confirmquery($drafting_post_via_checkboxes_query);
                    header("Location: posts.php");
                    break;
                    
                case 'delete':
                    $query = "DELETE FROM posts WHERE post_id = $cBAV";
                    $deleting_post_via_checkboxes_query = mysqli_query( $connection , $query );
                    confirmquery($deleting_post_via_checkboxes_query); 
                    header("Location: posts.php");
                    break;
                
                case 'clone':
                    $query = "SELECT * FROM posts WHERE post_id = $cBAV";
                    $select_checked_posts_query = mysqli_query($connection,$query);
                    confirmquery($select_checked_posts_query);
                    while($data_fetched = mysqli_fetch_assoc($select_checked_posts_query))
                    {
                        $post_title = $data_fetched['post_title'];
                        $post_author = $data_fetched['post_author'];
                        $post_image = $data_fetched['post_image'];
                        $post_content = $data_fetched['post_content'];
                        $post_tags = $data_fetched['post_tags'];
                        $post_status = 'draft';
                    }
                    
                    $query = "INSERT INTO posts(post_category_id,post_title,post_author,post_date,post_image,post_content,post_tags,post_comment_count,post_status) ";
                    $query .= "VALUES( 0 , '{$post_title}' , '{$post_author}' , now() , '{$post_image}' , '{$post_content}' , '{$post_tags}' , 0 , '{$post_status}' )";
                    $clone_query = mysqli_query($connection,$query);
                    confirmquery($clone_query);
                    header("Location: posts.php");
                                     
                default:
                    break;
            }
            
        }
    }

?>
   

<form action="" method="post">
    <table class="table table-responsive table-bordered table-hover">
       
       <div id="bulkOptionsContainer" class="col-xs-4">
           
           <select name="bulk_options" id="" class="form-control">
               
               <option value="">Select Options</option>
               <option value="publish">Publish</option>
               <option value="draft">Draft</option>
               <option value="delete">Delete</option>
               <option value="clone">Clone</option>
               
           </select>
           
       </div>
       
       <div class="col-xs-4">
           
           <input type="submit" onClick="javascript: return confirm('Are You Sure You Want to Take that Action of Selected Posts');" name="submit" class="btn btn-success" value="Apply" />
           <a href="posts.php?source=add_post" class="btn btn-primary">Add New</a>
           
       </div>
       
        <thead>
            <tr>
                <th><input type="checkbox" id="selectAllBoxes" /></th>
                <th>Id</th>
                <!--<th>Category</th>-->
                <th>Post Title</th>
                <th>Author</th>
                <th>Date</th>
                <th>Image</th>
                <th>Contents</th>
                <th>Tags</th>
                <th>Comment Count</th>
                <th>Status</th>
                <th colspan="2"><center>Action</center></th>
            </tr>
        </thead>
        <tbody>

                <?php

                    $query = "SELECT * FROM posts";
                    $posts_fetched_res = mysqli_query( $connection , $query );
                    while($data_fetched_posts = mysqli_fetch_assoc($posts_fetched_res))
                    {
                        $post_id = $data_fetched_posts['post_id'];
                        #$post_cat_id = $data_fetched_posts['post_category_id'];
                        $post_title = $data_fetched_posts['post_title'];
                        $post_author = $data_fetched_posts['post_author'];
                        $post_date = $data_fetched_posts['post_date'];
                        $post_image = $data_fetched_posts['post_image'];
                        $post_content = $data_fetched_posts['post_content'];
                        $post_tags = $data_fetched_posts['post_tags'];
                        $post_comm_counts = $data_fetched_posts['post_comment_count'];
                        $post_status = $data_fetched_posts['post_status'];

                        echo '<tr>';
                        ?>
                        <td>
                        <input type="checkbox" class="checkBoxes" name="checkBoxArray[]" value="<?php echo $post_id; ?>"/>
                        </td>
                        <?php
                        echo "<td>{$post_id}</td>";

                        #**** category
                        /*$query = "SELECT * FROM categories";
                        $select_all_cats_for_post = mysqli_query( $connection , $query );
                        confirmquery($select_all_cats_for_post);

                        while($data_fetched = mysqli_fetch_assoc($select_all_cats_for_post))
                        {
                        $cat_id = $data_fetched['cat_id'];
                        $post_cat_title = $data_fetched['cat_title'];
                        echo "<td>{$post_cat_title}</td>";
                        }*/

                        echo "<td>{$post_title}</td>";
                        echo "<td>{$post_author}</td>";
                        echo "<td>{$post_date}</td>";
                        echo "<td><img alt='img missing' width=50 src='../images/{$post_image}' /></td>";
                        echo "<td>{$post_content}</td>";
                        echo "<td>{$post_tags}</td>";
                        echo "<td>{$post_comm_counts}</td>";
                        echo "<td>{$post_status}</td>";
                        echo "<td><a class='btn btn-info' href='posts.php?source=edit_post&p_id={$post_id}'>Edit</a></td>";
                        echo "<td><a class='btn btn-danger' onClick=\"javascript: return confirm('Are You Sure You Want to Delete Post');\" href='posts.php?delete_post={$post_id}' >Delete</a></td>";
                        echo "</tr>";
                    }

                ?>

        </tbody>
    </table>
</form>

<?php

    #Deleting Posts
    if( isset($_GET['delete_post']) )
    {
        $del_post_id = $_GET['delete_post'];
        $query = "DELETE FROM posts WHERE post_id = {$del_post_id}";
        $del_post_query = mysqli_query( $connection , $query );
        confirmquery($del_post_query);
        header("Location: posts.php");
    }
    
?>