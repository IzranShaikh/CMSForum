<?php
    
    if(isset($_GET['p_id']))
    {
        $edit_post_id = $_GET['p_id'];
    }
    
    $query = "SELECT * FROM posts WHERE post_id = {$edit_post_id} ";
    $posts_fetched_res_by_id = mysqli_query( $connection , $query );
    while($data_fetched_posts = mysqli_fetch_assoc($posts_fetched_res_by_id))
    {
    $edit_post_id = $data_fetched_posts['post_id'];
    $edit_post_cat_id = $data_fetched_posts['post_category_id'];
    $edit_post_title = $data_fetched_posts['post_title'];
    $edit_post_author = $data_fetched_posts['post_author'];
    $edit_post_date = $data_fetched_posts['post_date'];
    $edit_post_image = $data_fetched_posts['post_image'];
    $edit_post_content = $data_fetched_posts['post_content'];
    $edit_post_tags = $data_fetched_posts['post_tags'];
    #$edit_post_comm_counts = $data_fetched_posts['post_comment_count'];
    $edit_post_status = $data_fetched_posts['post_status'];
    }
    
    #values from Form - post
    if(isset($_POST['edit_post_submit']))
    {
        $post_title = $_POST['edit_post_title'];
        $post_author = $_POST['edit_post_author'];
        #$post_category_id = $_POST['edit_post_cat_id'];
        $post_content = $_POST['edit_post_content'];
        $post_content = mysqli_real_escape_string( $connection , $post_content );
        $post_tags = $_POST['edit_post_tags'];

        #Image Updation
        $post_image = $_FILES['edit_post_image']['name'];
        $post_image_temp = $_FILES['edit_post_image']['tmp_name'];
        move_uploaded_file($post_image_temp, "../images/$post_image");

        $post_status = $_POST['edit_post_status'];

        #Editing Posts
        $query = "UPDATE posts SET ";
        $query .= "post_title = '{$post_title}', ";
        $query .= "post_category_id = NULL , ";
        $query .= "post_date = now() , ";
        $query .= "post_author = '{$post_author}', ";
        $query .= "post_status = '{$post_status}', ";
        $query .= "post_tags = '{$post_tags}', ";
        $query .= "post_content = '{$post_content}', ";
        $query .= "post_image = '{$post_image}' ";
        $query .= "WHERE post_id = {$edit_post_id} ";

        $update_post_query = mysqli_query($connection , $query);
        
        confirmquery($update_post_query);
        
        echo "<pre>Post Updated</pre>";
    }

    
?>

<form action="" method="post" enctype="multipart/form-data">
    
    <!--<div class="form-group">
        <label for="Post id">Post Id</label>
        <input type="text" name="add_post_id" class="form-control"/>
    </div>-->
    
    <div class="form-group">
        
        <!-- Post Category -->
        <!--<label for="post cat">Post Category</label>
        
        <select name="edit_post_cat_id" id="" class='form-control'>
            
            <?php

                /*$query = "SELECT * FROM categories";
                $select_all_cats_edit = mysqli_query( $connection , $query );
                confirmquery(select_all_cats_edit);
                while($data_fetched = mysqli_fetch_assoc($select_all_cats_edit))
                {
                $cat_id = $data_fetched['cat_id'];
                $cat_title = $data_fetched['cat_title'];
                echo "<option value='$cat_title'>$cat_title</option>";
                }*/

            ?>

        </select>-->
        
    </div>
    
    <div class="form-group">
        <label for="Post Title">Post Title</label>
        <input type="text" name="edit_post_title" value="<?php echo $edit_post_title; ?>" class="form-control"/>
    </div>
    
    <div class="form-group">
        <label for="Post Author">Post Author</label>
        <input type="text" name="edit_post_author" value="<?php echo $edit_post_author; ?>" class="form-control"/>
    </div>
    
    <!--<div class="form-group">
        <label for="Post Date">Post Date</label>
        <input type="text" name="add_post_date" class="form-control"/>
    </div>-->
    
    <div class="form-group">
        <label for="Post Image">Post Image</label>
        <input type="file" name="edit_post_image"/>
        <img width="100" src="../images/<?php echo $edit_post_image; ?>" alt="img not found" />
    </div>
    
    <div class="form-group">
        <label for="Post Content">Post Content</label>
        <!--Modern WYSIWYG-->
        <?php include"modernwysiwyg.php"; ?>
        <textarea name="edit_post_content" class="form-control"> <?php echo $edit_post_content; ?> </textarea>
    </div>
    
    <div class="form-group">
        <label for="Post Tags">Post Tags</label>
        <input type="text" name="edit_post_tags" value="<?php echo $edit_post_tags; ?>" class="form-control"/>
    </div>
    
    <!--<div class="form-group">
        <label for="Post Comm Count">Post Comm Count</label>
        <input type="text" name="edits_post_comm_cnt" value="<?php echo $edit_post_comm_counts; ?>" class="form-control"/>
    </div>-->
    
    <div class="form-group">
        <label for="Post Status">Post Status</label>
        <input type="text" name="edit_post_status" value="<?php echo $edit_post_status; ?>" class="form-control"/>
    </div>
    
    <input type="submit" class="btn btn-success" value="Update Post" name="edit_post_submit" />
    
</form>