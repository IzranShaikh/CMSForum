    <!-- Dropdown -->
    <!-- <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#">PHP</a>
        <a class="dropdown-item" href="#">JavaScript</a>
        <a class="dropdown-item" href="#">HTML+CSS</a>
        <a href="#" class="dropdown-item">NULL</a>
      </div>
    </li> -->
 <?php session_start(); ?>  
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <!-- <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button> -->
            <a class="navbar-brand" href="./index.php">Tech Blog</a>
        </div>
        
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
               <?php
                    #Fetching Navigation 1698
                    /*$query = "SELECT * FROM categories";
                    $select_all_cats = mysqli_query( $connection , $query );

                    while($data_fetched = mysqli_fetch_assoc($select_all_cats))
                    {
                        $cat_title = $data_fetched['cat_title'];
                        echo "<li> <a href='#'> {$cat_title} </a> </li>";
                    }*/
               ?>
               
               <!--DropDown Web Development-->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Web Development <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i ></i> PHP </a>
                        </li>
                        <li>
                            <a href="#"><i ></i> JavaScript </a>
                        </li>
                        <li>
                            <a href="#"><i ></i> HTML+CSS </a>
                        </li>
                        <li>
                            <a href="#"><i ></i> BootStrap </a>
                        </li>
                        
                        <!--Divider
                        <li class="divider">HR in LI</li>
                        -->
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Game Development <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i ></i> Unity - C# </a>
                        </li>
                        <li>
                            <a href="#"><i ></i> Python - Pygame Module </a>
                        </li>
                        <li>
                            <a href="#"><i ></i> Android Studio </a>
                        </li>
                        
                        <!--Divider
                        <li class="divider">HR in LI</li>
                        -->
                        
                    </ul>
                </li>
                
                <li>
                    <a href="registration.php">Register</a>
                </li>
                
                <!--Login Logout Status-->
                <?php
                
                if( isset($_SESSION['username_s']) and isset($_SESSION['password_s']) )
                {
                
                ?>
                                      
                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['username_s']; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                    <li>
                        <a href="./user_profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                    </li>
                    <li class="divider">HR in LI</li>
                    <li>
                        <a href="./includes/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                    </li>
                    </ul>
                    </li>
                    <?php
                    if( isset($_SESSION['username_s']) and isset($_SESSION['password_s']) and $_SESSION['user_role_s'] == 'admin' )
                    {
                    ?>
                    <li><a href="admins/">Admins</a></li>
                    <?php
                    }
                    ?>
                <?php
                }
                ?>
                
            </ul>
        </div>
    </div>
    
</nav>