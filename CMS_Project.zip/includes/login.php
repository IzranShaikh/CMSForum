<?php include"db_conn.php"; ?>
<?php include"../admins/functions.php"; ?>
<?php session_start(); ?>
<?php

    if(isset($_POST['login']))
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
//        $username = mysqli_real_escape_string($connection , $username);
//        $password = mysqli_real_escape_string($connection , $password);
        $query = "SELECT randsalt from users";
        $select_randsalt_query = mysqli_query( $connection , $query );
        if(!$select_randsalt_query)
        {
            die("Query Failed " . mysqli_error($connection));
        }
        $data_fetched = mysqli_fetch_assoc($select_randsalt_query);
        $HASH = $data_fetched['randsalt'];
        $password = crypt($password,$HASH);
        $query = "SELECT * FROM users WHERE username = '$username' AND user_password = '$password'";
        $select_user_query = mysqli_query( $connection , $query );
        confirmquery($select_user_query);
        
        while($data_fetched = mysqli_fetch_assoc($select_user_query))
        {
            $db_username = $data_fetched['username'];
            $db_user_role = $data_fetched['user_role'];
            $db_password = $data_fetched['user_password'];
            $db_firstname = $data_fetched['user_firstname'];
            $db_lastname = $data_fetched['user_lastname'];
            $db_user_email = $data_fetched['user_email'];
            $db_user_image = $data_fetched['user_image'];
        }
        
        if( !empty($db_username) and !empty($db_password) )
        {
            #SESSIONS
            if( $username == $db_username and $password == $db_password )
            {
                #Users Login
                $_SESSION['username_s'] = $db_username;
                $_SESSION['user_role_s'] = $db_user_role;
                $_SESSION['password_s'] = $db_password;
                $_SESSION['firstname_s'] = $db_firstname;
                $_SESSION['lastname_s'] = $db_lastname;
                $_SESSION['emailid_s'] = $db_user_email;
                $_SESSION['user_image_s'] = $db_user_image;
                header("Location: ../admins");
            }
            
            /*Not Appropriate
            else if( $username == $db_username and $password == $db_password )
            {
                #User Login
                $_SESSION['username_s'] = $db_username;
                $_SESSION['user_role_s'] = $db_user_role;
                $_SESSION['password_s'] = $db_password;
                $_SESSION['firstname_s'] = $db_firstname;
                $_SESSION['lastname_s'] = $db_lastname;
                echo "<span style='color:green;'>Logged In</span>";
            }*/
        }
        else
        {
            echo "<span style='color:red;'>Invalid Username or Password</span>";
        }
    }

?>