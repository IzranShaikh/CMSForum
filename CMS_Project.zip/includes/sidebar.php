<div class="col-md-4">
    
    
    <!-- Search Engine -->
    <div class="well">
        <h4>Search Posts</h4>
        <form method="post" action="search.php">
            <div class="input-group">
                <input type="text" name="search_bar_val" class="form-control"/>
                <span class="input-group-btn">
                    <button name="submit" type="submit" class="btn btn-default" type="button"><span class="glyphicon glyphicon-search"></span></button>
                </span>
            </div>
        </form><!--Search Engine Sect Ends-->
        <!-- /.input-group -->
    </div>

    <div class="well">
        <?php
        if( !(isset($_SESSION['username_s'])) )
        {
        ?>
        <h4>Login</h4>
        <form method="post" action="includes/login.php">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" class="form-control" required/>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password" class="form-control" required/>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit" name="login">Login</button>
                </span>
            </div>
        </form>
        <?php
        }
        else
        {
            echo "<span style='color:green;'>Logged In</span>";
        }
        ?>
    </div>

   
    <!-- Blog Categories -->
    <div class="well">
       
       <?php
                        
            $query = "SELECT * FROM categories";
            $select_all_cats_sidebar = mysqli_query( $connection , $query );
                    
        ?>
       
        <h4>Blog Categories</h4>
        <div class="row">
            <div class="col-lg-6">
                <ul class="list-unstyled">
                   
                   <?php
                    
                        while($data_fetched = mysqli_fetch_assoc($select_all_cats_sidebar))
                        {
                            $cat_title = $data_fetched['cat_title'];
                            $cat_id = $data_fetched['cat_id'];
                            echo "<li><em>{$cat_title}</em></li>";
                        }
                    
                    ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Side Widget Well -->
    <?php include"widget.php"; ?>
    
</div>