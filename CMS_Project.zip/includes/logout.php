<?php session_start(); ?>


<?php

    $_SESSION['username_s']  = null;
    $_SESSION['user_role_s'] = null;
    $_SESSION['password_s']  = null;
    $_SESSION['firstname_s'] = null;
    $_SESSION['lastname_s']  = null;

    session_destroy();

    header("Location: ../index.php");

?>