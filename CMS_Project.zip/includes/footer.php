    </div>
    <!-- /.container -->
    <!-- Footer -->
    <footer>
        <center><p style="color:black;background-color:white;">Copyright &copy; CMS - Izran 2018</p></center>
    </footer>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
<?php 

$serverinfo = $_SERVER;

?>
</body>

</html>