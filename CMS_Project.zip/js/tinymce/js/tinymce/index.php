<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Test of WYSIWYG</title>
	<script type="text/javascript" src="tinymce.min.js"></script>
	<script>
		tinymce.init({ selector:'textarea' });
	</script>
</head>
<body>
	<textarea>Not Working</textarea>
</body>
</html>